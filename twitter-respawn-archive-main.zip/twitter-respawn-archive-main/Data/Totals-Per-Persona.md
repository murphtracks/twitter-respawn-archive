| Persona                | Approx Group              | Accounts |
| ---------------------- | ------------------------- | -------- |
| Kaspa                  | The Shed                  | 256      |
| Elephant Jockey        | The Shed                  | 189      |
| British Dean           | British Racist            | 136      |
| Gigi                   | The Shed                  | 133      |
| Pikachu                | Nazi / Shed adj           | 133      |
| Spicci                 | The Shed                  | 130      |
| Shane                  | The Shed                  | 123      |
| Poffo                  | The Shed                  | 120      |
| Violet                 | The Shed                  | 117      |
| KYE                    | The Shed                  | 109      |
| Nuke                   | The Shed                  | 97       |
| Huwhite                | The Shed                  | 92       |
| King Adam/Ritsu        | Nazi                      | 86       |
| Shlomo                 | The Shed                  | 84       |
| LiA                    | The Shed                  | 76       |
| Six Million            | The Shed                  | 75       |
| iE - Chick-fil-A       | The Shed                  | 74       |
| Commish                | The Shed                  | 72       |
| H3ll Billy             | The Shed                  | 62       |
| Boeta                  | The Shed                  | 60       |
| Trill Bread            | Nazi Lounge               | 60       |
| Foreskin               | The Shed                  | 58       |
| Gabe                   | Anitwtkkk                 | 58       |
| Roscoe                 | The Shed / Houseboat gang | 58       |
| ESS                    | The Shed                  | 57       |
| Mel Gibson Fan         | The Shed                  | 56       |
| SammyGunz              | The Shed                  | 54       |
| iE                     | The Shed                  | 50       |
| Frat                   | The Shed                  | 49       |
| Bear                   | The Shed                  | 44       |
| Brit Groyper           | Groyper                   | 44       |
| Mimikyu                | Anitwtkkk                 | 41       |
| Baked                  | The Shed                  | 40       |
| Cind                   | Anitwtkkk                 | 40       |
| Iqbal                  | The Shed                  | 40       |
| Tucker                 | RGC                       | 40       |
| HawG                   | Shed adj                  | 39       |
| Alzoura                | Anitwtkkk                 | 38       |
| Gibs                   | The Shed                  | 38       |
| JoeH                   | The Shed                  | 38       |
| Neighborly             | The Shed                  | 38       |
| Normal Korean          | The Shed                  | 38       |
| Larry                  | Shed adj                  | 37       |
| Alt Skull / Puppers    | The Shed                  | 36       |
| Gayle                  | The Shed                  | 36       |
| Kayak Slammer          | The Shed                  | 36       |
| Rebel Pen              | The Shed                  | 36       |
| Evan                   | The Shed                  | 35       |
| Mugi                   | Shed adj / Anitwtkkk adj  | 35       |
| Stu                    | Fren / Shed adj           | 34       |
| Ulrich                 | Nazi Lounge               | 34       |
| Axl                    | The Shed                  | 33       |
| Toast                  | RGC adj                   | 33       |
| Weather Groyper        | Groyper                   | 33       |
| Whllpers               | RGC                       | 33       |
| Fedposter              | Patriot Front             | 32       |
| Gibbs                  | The Shed                  | 32       |
| Whaler                 | The Shed                  | 32       |
| Triangle               | Nazi Lounge               | 31       |
| Jackson                | The Shed                  | 31       |
| Autism                 | The Shed                  | 30       |
| Cushy                  | Anitwtkkk                 | 30       |
| TheShed                | The Shed                  | 30       |
| Vernon                 | The Shed                  | 30       |
| Pressman               | Racist Troll              | 29       |
| Spectre                | The Shed                  | 29       |
| TheShed - Fake         | The Shed                  | 29       |
| Chix                   | Nazi Lounge               | 28       |
| Frakes                 | The Shed                  | 28       |
| Nonjob                 | Nazi                      | 28       |
| OzBrah                 | Nazi Lounge               | 28       |
| Pumba                  | The Shed                  | 28       |
| Chemist Groyper        | America First             | 27       |
| Honk Hogan             | The Shed                  | 27       |
| Nick Fuentes           | America First             | 27       |
| Riggs                  | Nazi / Shed adj           | 27       |
| Anime Avi / CO Groyper | America First             | 26       |
| Steven Dwayne          | The Shed                  | 26       |
| ATL                    | The Shed                  | 25       |
| Boulder                | Nazi Lounge               | 25       |
| Fr. Groyper            | The Shed                  | 25       |
| Wern                   | Nazi                      | 25       |
| Floki                  | The Shed                  | 24       |
| Lah Tee                | Fren / Shed adj           | 24       |
| Philia                 | Anitwtkkk                 | 24       |
| Boston Groyper         | America First             | 23       |
| Gregzthetic            | Nazi                      | 23       |
| Vader                  | The Shed                  | 23       |
| Vasily                 | Wignat                    | 23       |
| Dalai                  | The Shed                  | 22       |
| Johnny                 | Nazi                      | 22       |
| Jqhnny                 | The Shed                  | 22       |
| Zyklon                 |                           | 22       |
| CJ Wylin               |                           | 21       |
| Hans                   | The Shed                  | 21       |
| ICE                    | The Shed                  | 21       |
| Mack Groyper           | America First             | 21       |
| PZ                     | America First             | 21       |
| Alles / WifeOfFloki    | The Shed                  | 20       |
| Balrog                 | The Shed                  | 20       |
| Khan                   | Nazi                      | 20       |
| Pen                    |                           | 20       |
| Trans Ls               | RW Gimmick                | 20       |
| Voki                   | Nazi Lounge               | 20       |
| Zepp                   | Nazi                      | 20       |
| Ames                   | Shed adj                  | 19       |
| Censored Nate          | America First             | 19       |
| Cimit                  | RGC                       | 19       |
| Cino                   | The Shed                  | 19       |
| DL                     | The Shed                  | 19       |
| Jupiter                | Wignat                    | 19       |
| Kato                   |                           | 19       |
| Logan                  |                           | 19       |
| Lone zoomer            | America First             | 19       |
| Microchip              | The Shed                  | 19       |
| Niggasaki              | The Shed                  | 19       |
| Wolfgang               | RGC                       | 19       |
| Amerikaner             | America First             | 18       |
| Boston Zoomer          | America First             | 18       |
| Bunts                  | Nazi                      | 18       |
| Gallowglass            | Nazi                      | 18       |
| Goose Man              | NL adj / Shed adj         | 18       |
| Holo                   | Nazi                      | 18       |
| KatyLovesEva           | Anitwtkkk                 | 18       |
| Lemon K                | Nazi Lounge               | 18       |
| Ace                    | Nazi                      | 17       |
| CJ                     |                           | 17       |
| Elusive Fox            | Racist Troll              | 17       |
| Ku Klux Klan           | KKK                       | 17       |
| Nate                   | Nazi                      | 17       |
| Plerome                | Patriot Front adj         | 17       |
| Racist Ws              | RW Gimmick                | 17       |
| DrafNat                | America First             | 16       |
| HHH                    | The Shed                  | 16       |
| Jimbo                  | America First             | 16       |
| Whitaker's Mantra      | White Nationalist         | 16       |
| B Wood                 | Shed adj                  | 15       |
| Dog Shit               | Nazi                      | 15       |
| Gino                   |                           | 15       |
| Godwin                 | Nazi                      | 15       |
| HoneyBad               | The Shed                  | 15       |
| Jason                  | RGC adj                   | 15       |
| Lucid                  | Nazi                      | 15       |
| Mac                    | Shed adj                  | 15       |
| Mira                   | Nazi                      | 15       |
| Nose                   | The Shed                  | 15       |
| Petrus                 | Nazi                      | 15       |
| Suburban Groyper       | America First             | 15       |
| TomAF                  | Nazi / Shed adj           | 15       |
| Big Tone               | Nazi                      | 14       |
| Doug                   | Irony bro                 | 14       |
| Hank Chill             | Irony bro                 | 14       |
| Lil Naz                |                           | 14       |
| Luffy                  | Nazi                      | 14       |
| Mabel Gator            | Fren / Shed adj           | 14       |
| Mark Mac               | The Shed                  | 14       |
| Maul                   | The Shed                  | 14       |
| Noah                   | Nazi                      | 14       |
| Raj Lion               |                           | 14       |
| schutz                 |                           | 14       |
| Skeleton               | Nazi                      | 14       |
| Sulayman               | Nazi                      | 14       |
| AF Zoomer              | America First             | 13       |
| Aims                   | The Shed                  | 13       |
| Amerimutt              | RGC adj                   | 13       |
| Fascist Friend         | Nazi                      | 13       |
| Guy Fieri              | America First             | 13       |
| James                  | The Shed                  | 13       |
| Jay Austin Graham      |                           | 13       |
| Jeffler                | Nazi Prop                 | 13       |
| Joes Chipper           |                           | 13       |
| John Palmer            | Patriotic Alternative     | 13       |
| Kook                   | The Shed                  | 13       |
| Lord Maryland          | America First             | 13       |
| Manslow                | The Shed                  | 13       |
| Missouri Fren          | America First             | 13       |
| Pinx                   | The Shed                  | 13       |
| Rigby                  | RGC                       | 13       |
| TalmudicTactics        | The Shed networking point | 13       |
| Tato                   | Groyper                   | 13       |
| Texan                  | Nazi                      | 13       |
| Truth                  |                           | 13       |
| Utah Zoomer            | America First             | 13       |
| Volnost                | Nazi Prop                 | 13       |
| Waifumaster / Thighs   | Anitwtkkk                 | 13       |
| Zuck                   |                           | 13       |
| Bruhther               | Wignat                    | 12       |
| Captain Cod            | Nazi                      | 12       |
| Epicness               | RGC                       | 12       |
| Flop                   | RGC                       | 12       |
| Gaelex                 |                           | 12       |
| Genetic                | Anitwtkkk                 | 12       |
| Humble                 |                           | 12       |
| Johnny Fedpost         | Groyper                   | 12       |
| MF Doomer              | Nazi                      | 12       |
| Nebraska Zoomer        | America First             | 12       |
| Neverland Antifa       | The Shed                  | 12       |
| Pasty                  | Nazi                      | 12       |
| Rookie                 | RGC                       | 12       |
| SPF                    | The Shed networking point | 12       |
| Stalker / Thulean      | RGC adj                   | 12       |
| Taylor                 | Shed adj / WN             | 12       |
| Trader                 | The Shed                  | 12       |
| Tyler Durden           |                           | 12       |
| Utah Groyper           | America First             | 12       |
| Wei-Han Zheng          | The Shed                  | 12       |
| Baked Alaska           | America First             | 11       |
| Burger Fren            | Fren                      | 11       |
| Cheryl                 | White Nationlist          | 11       |
| Eric                   | Nazi                      | 11       |
| Floyd                  | RGC                       | 11       |
| Good Boy UV            | Fren / Shed adj           | 11       |
| iE Antifa              | The Shed                  | 11       |
| IRLAltRight            |                           | 11       |
| Jogge                  | Nazi                      | 11       |
| Josef Bosch            |                           | 11       |
| Kansas Zoomer          | America First             | 11       |
| Karl                   |                           | 11       |
| Lumiere                |                           | 11       |
| Niko                   |                           | 11       |
| Patriot Front          | Patriot Front             | 11       |
| Rex                    |                           | 11       |
| Rogle                  | Nazi                      | 11       |
| Shep                   | DogRight                  | 11       |
| Sian                   | British Racist            | 11       |
| Skorr                  | RGC                       | 11       |
| Sortress               | Nazi                      | 11       |
| Tanya                  | Anitwtkkk                 | 11       |
| Tin Pan Man            | America First             | 11       |
| Unkle Frosty           | The Shed                  | 11       |
| Anita                  | The Shed                  | 10       |
| Aragorn                | The Shed                  | 10       |
| Baku                   |                           | 10       |
| Bane Biddix            |                           | 10       |
| Breeze                 | America First             | 10       |
| CW Patriot             | America First             | 10       |
| David Santa Carla      | The Shed                  | 10       |
| Deus                   | Nazi                      | 10       |
| Doffy                  | Nazi                      | 10       |
| Five                   |                           | 10       |
| Helen Smeller          | The Shed                  | 10       |
| Iepseh                 | America First             | 10       |
| Manlet                 | Shed adj                  | 10       |
| McRib                  |                           | 10       |
| Mike Peinovich         | TRS / NJP                 | 10       |
| PeePee                 |                           | 10       |
| Peter Cozy             | The Shed                  | 10       |
| Shooter                | Nazi                      | 10       |
| Vince                  | Nazi                      | 10       |
| Virginia Groyper       | America First             | 10       |
| Yuicel                 | Anitwtkkk                 | 10       |
| Zoomerhead             | America First             | 10       |
| Absolute Zero          | Shed adj                  | 9        |
| Anime Gamer            | Anitwtkkk                 | 9        |
| Big Tex Zoomer         | America First             | 9        |
| Blacktric              | Groyper                   | 9        |
| Borzoi                 | TRS adj                   | 9        |
| Cujo                   | Shed adj                  | 9        |
| EllieBelle             | Fren / WN                 | 9        |
| Florida Groyper        | America First             | 9        |
| Floyd Pepper           |                           | 9        |
| Habits                 | Nazi                      | 9        |
| Jinx                   | Irony bro                 | 9        |
| Lone Star Groyper      | America First             | 9        |
| Luke                   | Nazi                      | 9        |
| Mares                  | Shed adj                  | 9        |
| Maximus                | Nazi                      | 9        |
| Mewlina                | Nazi                      | 9        |
| Nap                    | Anitwtkkk                 | 9        |
| Outsider               | The Shed networking point | 9        |
| Roboleader             | America First             | 9        |
| Sachsy                 | Shed adj                  | 9        |
| Shub                   |                           | 9        |
| Sky King               | Shed adj                  | 9        |
| Skylar                 | The Shed                  | 9        |
| Slav GSP               | RGC                       | 9        |
| Tulip                  |                           | 9        |
| Ulrica                 |                           | 9        |
| Vic                    |                           | 9        |
| Zhang                  | The Shed                  | 9        |
| Alabama Hobo           | The Shed                  | 8        |
| Based British          | Nazi                      | 8        |
| Blutige                | Nazi                      | 8        |
| Boomer                 |                           | 8        |
| Border Reiver          |                           | 8        |
| Braithwaite            |                           | 8        |
| Bronze Age Scientist   | Groyper                   | 8        |
| Calcium                | Nazi                      | 8        |
| Chet                   | Nazi                      | 8        |
| Chief Trumpster        | America First             | 8        |
| Chungus                | Nazi                      | 8        |
| Comfy Party            | America First             | 8        |
| Defend Evropa          | Nazi                      | 8        |
| Doggo / LoneArgos      | Groyper / WN              | 8        |
| Earth Rabbit           | Nazi                      | 8        |
| Eva                    | The Shed                  | 8        |
| Gersh                  | America First / Groyper   | 8        |
| GoldenEye Groyper      | Groyper                   | 8        |
| GS Patton              | America First             | 8        |
| Jared                  |                           | 8        |
| Jeffrey                | RGC                       | 8        |
| Jej                    | Nazi                      | 8        |
| Jordy                  | Nazi                      | 8        |
| Josh                   |                           | 8        |
| Kate / Redscarf        | The Shed                  | 8        |
| Kiwi / Werly           | Nazi                      | 8        |
| Lamarv Groyper         | Groyper                   | 8        |
| Lamia                  |                           | 8        |
| Lucky                  |                           | 8        |
| Magic Groyper          | America First             | 8        |
| Mantaur                | The Shed                  | 8        |
| McFed Comics           | Nazi                      | 8        |
| Michael Alberto        | America First             | 8        |
| Mittens                | Nazi                      | 8        |
| Molly                  | British Racist            | 8        |
| Nef                    | The Shed                  | 8        |
| Oregon Zoomer          | America First             | 8        |
| Pax                    | Tradcath / Anitwtkkk adj  | 8        |
| Polyblank              | Anitwtkkk                 | 8        |
| Rape 7                 | RGC                       | 8        |
| Ridder / Fordo         | RGC                       | 8        |
| Rob Banks              |                           | 8        |
| Rob Recht              | Shed adj / Nazi           | 8        |
| Swams                  | Fren / Shed adj           | 8        |
| Tapped In              | Nazi Lounge               | 8        |
| Templar                | British Racist            | 8        |
| Trey Apollo            | America First             | 8        |
| Troll Killer           | Troll                     | 8        |
| Troy                   |                           | 8        |
| Uncle Billy            | Nazi                      | 8        |
| Volkish Pedophile      | Anitwtkkk                 | 8        |
| Zenok                  | Anitwtkkk                 | 8        |
| AnimeRapist / Cookie   | Nazi                      | 7        |
| Arty                   | Anitwtkkk                 | 7        |
| Ash                    | Nazi Lounge               | 7        |
| Auto Sear              | The Shed                  | 7        |
| Bee Heaven             | Nazi                      | 7        |
| Belgie                 | Nazi                      | 7        |
| Biggie Slonk           | Nazi Prop                 | 7        |
| Celtic Lady            | WN / Shed adj             | 7        |
| Cheeseman350           | RGC                       | 7        |
| Chicago Joe            |                           | 7        |
| Cosmist                | NRx / Other               | 7        |
| Cougar                 |                           | 7        |
| Demography             |                           | 7        |
| Dennis                 | RW Gimmick                | 7        |
| Dondo                  | Racist Troll              | 7        |
| Facts Are Antisemitic  | Nazi                      | 7        |
| Fake Imam              |                           | 7        |
| Gator                  | Nazi                      | 7        |
| Gergilla               | RGC adj                   | 7        |
| graf                   |                           | 7        |
| GroyperWave            |                           | 7        |
| Halo CE / John Halo    | RGC                       | 7        |
| Helios/AF              | Nazi                      | 7        |
| Hydrazine              | Nazi                      | 7        |
| JarodKintz             |                           | 7        |
| JoeyCamp               |                           | 7        |
| Jwoke                  |                           | 7        |
| Kaguya                 | Nazi / RGC adj            | 7        |
| Kai                    | America First             | 7        |
| Kred                   |                           | 7        |
| Laura N                | Nazi                      | 7        |
| Lemon NaCl             | Nazi Lounge               | 7        |
| Lindbergh              | Nazi                      | 7        |
| Locke                  |                           | 7        |
| Maria Lost             | Nazi                      | 7        |
| Midwest Groyper        | America First             | 7        |
| Mika                   | The Shed                  | 7        |
| Mista S                | The Shed                  | 7        |
| Monke                  | Nazi                      | 7        |
| Natty                  |                           | 7        |
| New York Zoomer        | America First             | 7        |
| Nicky Wright           |                           | 7        |
| Nihilist               | Anitwtkkk                 | 7        |
| Otto Skorzeny          | RGC                       | 7        |
| Panda                  |                           | 7        |
| Pavel                  | Irony bro / RGC adj       | 7        |
| Racist Fisherman       | Nazi                      | 7        |
| Ro                     | RGC                       | 7        |
| salofaista             | Nazi                      | 7        |
| Scars                  |                           | 7        |
| Shadilay               |                           | 7        |
| Sokode                 | Nazi                      | 7        |
| Static Age             | The Shed                  | 7        |
| Tewdrig                | British Racist            | 7        |
| Tide                   | Nazi                      | 7        |
| Tully Rhodes           |                           | 7        |
| Valley Zoomer          | America First             | 7        |
| Vibes                  | RGC adj                   | 7        |
| Viceroy                | RW Gimmick                | 7        |
| Waffle                 |                           | 7        |
| Wanderer               | Nazi                      | 7        |
| WestAfrika             | Nazi                      | 7        |
| 0Hour                  |                           | 6        |
| Anitaku                | Anitwtkkk                 | 6        |
| Anon Crusader          | America First             | 6        |
| AOC                    |                           | 6        |
| Apple                  | RGC                       | 6        |
| Arctic Ron             | The Shed                  | 6        |
| AusNat                 |                           | 6        |
| B Rooster              | The Shed                  | 6        |
| Bananas                |                           | 6        |
| Bane                   |                           | 6        |
| Been                   | America First             | 6        |
| Buggy                  | Nazi                      | 6        |
| Cat                    |                           | 6        |
| CeoOfMarisa            | Anitwtkkk                 | 6        |
| CF Groyper             | Groyper                   | 6        |
| Charlee                | White Nationalist         | 6        |
| ChooseYourFighter      | Shed adj                  | 6        |
| Condor                 |                           | 6        |
| Cookie                 |                           | 6        |
| Culper                 | Patriot Front             | 6        |
| Darb                   | Shed adj                  | 6        |
| Doug Stewart           | The Shed                  | 6        |
| Dr. Based              | Nazi                      | 6        |
| Dr. Troon              | The Shed                  | 6        |
| Duke of Durham         |                           | 6        |
| Fashway                | Nazi                      | 6        |
| Fero                   | Nazi                      | 6        |
| Flambo                 |                           | 6        |
| Freya                  | RGC adj                   | 6        |
| Goose Fren             | NL adj / Shed adj         | 6        |
| Gribbles               | Nazi                      | 6        |
| Grievous               |                           | 6        |
| Grogu                  | The Shed                  | 6        |
| Groyper S Patton       | America First             | 6        |
| Guy Fieris Alt         | America First             | 6        |
| Heavywash              |                           | 6        |
| Heisenberg             | Nazi Lounge               | 6        |
| Hitler or Nazi         |                           | 6        |
| Hotler                 | Nazi                      | 6        |
| Hunter Wallace         | OccDis                    | 6        |
| Indian Groyper         | America First             | 6        |
| Infrequent             | Groyper / Fren            | 6        |
| JDog Pitler            | The Shed                  | 6        |
| Joe Roganstein         | Shed adj                  | 6        |
| Kayama                 | Nazi                      | 6        |
| Lagud                  |                           | 6        |
| LordVenus              | Nazi                      | 6        |
| Luke Mahler            | Patriot Prayer            | 6        |
| Lulu                   |                           | 6        |
| Manon                  | Nazi                      | 6        |
| Mean Girl Kat          | The Shed                  | 6        |
| Meiji                  | Nazi                      | 6        |
| Moria                  |                           | 6        |
| Nathaniel              | Nazi                      | 6        |
| Newman                 |                           | 6        |
| Nocturne               | Nazi                      | 6        |
| Nuts                   | Nazi                      | 6        |
| OKSign                 |                           | 6        |
| Osvanska / Ricky       | The Shed                  | 6        |
| Patrician              |                           | 6        |
| Paul Gosar Fan         | America First             | 6        |
| Pix                    |                           | 6        |
| Pullman                |                           | 6        |
| Punished K             | RGC                       | 6        |
| Radio Portal           | Nazi                      | 6        |
| Radioactive Redneck    | The Shed                  | 6        |
| Rape Champ             | British Racist            | 6        |
| Rapist                 | Nazi                      | 6        |
| SamHouston             | Shed adj / Nazi           | 6        |
| Shortbread             | RGC                       | 6        |
| Smug                   | Shed adj                  | 6        |
| Snek                   | Nazi                      | 6        |
| Sonnen                 | Nazi                      | 6        |
| Spooky Ghost           | Nazi                      | 6        |
| Strawberry Kat         | Nazi                      | 6        |
| Teak Tree              |                           | 6        |
| Ted / Forest           |                           | 6        |
| Texan Groyper          | America First             | 6        |
| Thuletide / SP         | America First             | 6        |
| TradWife               | SinglePurposeHateAcct     | 6        |
| Trevor                 | Nazi                      | 6        |
| Varg Vikernes          | Nazi                      | 6        |
| Vinnie Sullivan        | British Racist            | 6        |
| Willem Pearson         |                           | 6        |
| William (Malvern)      |                           | 6        |
| 45th                   |                           | 5        |
| AF Spongebob           | America First             | 5        |
| Afreewhiteman          | Nazi                      | 5        |
| Alba Rising            | British Racist            | 5        |
| Anglo-Celt             |                           | 5        |
| Anne                   |                           | 5        |
| Annie K                |                           | 5        |
| Arch Dornan            |                           | 5        |
| AZ Chad                | America First             | 5        |
| Banquo                 |                           | 5        |
| Barbarian              | Fren                      | 5        |
| Basil                  |                           | 5        |
| Bateman                |                           | 5        |
| Beardson               | Irony bro                 | 5        |
| Bilbo                  | RGC                       | 5        |
| Caudillo               | Irony bro / WN            | 5        |
| Chilli Heaven          | America First             | 5        |
| Cringenat              | Nazi                      | 5        |
| Cunny                  | Loli                      | 5        |
| Darren                 | Nazi                      | 5        |
| DavePilled             |                           | 5        |
| DJD                    | The Shed                  | 5        |
| Drew                   |                           | 5        |
| Dumpster Truffle       | The Shed                  | 5        |
| Dutch                  |                           | 5        |
| Earl / Dr0pp           | Shed adj                  | 5        |
| Ed Costa               |                           | 5        |
| Eldian Nationalist     | America First             | 5        |
| Elf                    | Nazi                      | 5        |
| Emery                  |                           | 5        |
| Fashy Yui              | Anitwtkkk                 | 5        |
| Ferret                 | RGC                       | 5        |
| Festipostnicken        |                           | 5        |
| Fiddy                  |                           | 5        |
| Floki as Jumpy Jew     | The Shed                  | 5        |
| Franco                 | Nazi                      | 5        |
| Frederic Pine          | Patriot Front             | 5        |
| Freeman                | RGC                       | 5        |
| frogwave / cattle      | Nazi                      | 5        |
| Fuhr                   |                           | 5        |
| George                 |                           | 5        |
| Hettane                |                           | 5        |
| Hornt Fren             | Nazi                      | 5        |
| Horse                  | Nazi                      | 5        |
| Hostis                 | RGC adj                   | 5        |
| Hulk Hogan Groyper     | America First             | 5        |
| Ian / Mycroft          | UK racist                 | 5        |
| Irish Rose             | White Nationalist         | 5        |
| JackFell               | Nazi                      | 5        |
| Jesse Dunstan, TRS     | TRS                       | 5        |
| Jiu Jitsu Groyper      | Groyper                   | 5        |
| Joe Prichard           | WN Podcaster              | 5        |
| Karen                  | Shed adj                  | 5        |
| Karen Za               |                           | 5        |
| Kayak                  |                           | 5        |
| Krissy                 | Shed adj                  | 5        |
| Lenton                 | America First             | 5        |
| Longshanks             |                           | 5        |
| Ls                     | RW Gimmick                | 5        |
| Mario                  | Nazi                      | 5        |
| Mia Vendetta           |                           | 5        |
| Music Groyper          | America First             | 5        |
| N.I.G                  | Shed adj                  | 5        |
| Negev Chan             | Nazi                      | 5        |
| Neo Rechts             |                           | 5        |
| New Age Chaos          | Nazi                      | 5        |
| NS                     | Nazi                      | 5        |
| Oklahoma Groyper       | America First             | 5        |
| Patricius              |                           | 5        |
| PedoTim                |                           | 5        |
| Penn G                 | America First             | 5        |
| Pepejaa                | America First             | 5        |
| Pilled Brah            | America First             | 5        |
| Polish Broadcasting    | RGC                       | 5        |
| Principled Groyper     | America First             | 5        |
| Prinny                 |                           | 5        |
| PrissyAnne             | The Shed                  | 5        |
| Psi                    | America First             | 5        |
| RWLS                   | Shed adj                  | 5        |
| Ryu                    |                           | 5        |
| Sam Hyde               | Irony bro                 | 5        |
| Sassy Blonde           | White Nationalist         | 5        |
| Scooby                 | Nazi                      | 5        |
| Setesh Tarentola       | Racist Troll              | 5        |
| Shaniqua PhD           | The Shed                  | 5        |
| Smails                 | Groyper                   | 5        |
| Smeed                  | Nazi                      | 5        |
| Stacby                 | Fren                      | 5        |
| Stacy Redvirgo         | Shed adj / WN             | 5        |
| Steve James            | English racist            | 5        |
| TappedIn               | Nazi Lounge               | 5        |
| Thulean Friend         | Nazi                      | 5        |
| Tre                    | Racist Troll              | 5        |
| Turd Ferguson          | Nazi                      | 5        |
| Twig Right             |                           | 5        |
| Unit 8200              | Nazi                      | 5        |
| USS Liberty Survivor   | Nazi                      | 5        |
| Wave                   |                           | 5        |
| William                |                           | 5        |
| Woodsy                 | White Nationalist         | 5        |
| Zeren                  |                           | 5        |
